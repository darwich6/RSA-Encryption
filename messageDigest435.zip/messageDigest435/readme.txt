http://www.zedwood.com/article/cpp-sha256-function
